"""
Mini-Projeto Avaliativo - Análise Exploratória (AED) da base Varejo
Curso: Análise de Dados com Python (Módulo 1 - Semana 07)

Como rodar:
    VsCode : python miniprojeto_varejo.py
    Colab  : envie o arquivo da base e este script, depois rode: !python miniprojeto_varejo.py

O script está dividido em Sprints (mesma ordem do enunciado):
    Sprint 1 - Importação dos dados
    Sprint 2 - Funções de limpeza (texto, inteiros, decimais) e datas
    Sprint 3 - Nulos e duplicatas
    Sprint 4 - Estatística descritiva (número de filhos)
    Sprint 5 - Agrupamentos e relatório final
"""
import os                       # verificar se o arquivo existe
import re                       # expressões regulares (limpeza de texto e números)
from datetime import datetime   # conversão de texto para data
import pandas as pd

# ---------------------------------------------------------------------------
# CONFIGURAÇÕES (constantes em MAIÚSCULAS: valores definidos uma única vez)
# ---------------------------------------------------------------------------
CAMINHOS_POSSIVEIS = [
    "data/Base_Varejo_csv.zip",
    "data/Base Varejo.csv",
    "Base_Varejo_csv.zip",
    "Base Varejo.csv",
]
ARQUIVO_SAIDA = "df_limpo.csv"
FORMATO_DATA = "%d/%m/%Y"       # dia/mês/ano (padrão brasileiro)
CATEGORIA_VAZIA = "SEM CATEGORIA"


def titulo(texto):
    """Imprime um título de seção, para deixar o relatório do terminal organizado."""
    print("\n" + "=" * 65)
    print(texto)
    print("=" * 65)


# ===========================================================================
# SPRINT 1 - IMPORTAÇÃO DOS DADOS
# ===========================================================================
def carregar_base():
    """Procura o arquivo da base e lê com pd.read_csv()."""
    for caminho in CAMINHOS_POSSIVEIS:
        if os.path.exists(caminho):
            print(f"Arquivo encontrado: {caminho}")
            # sep=";"           -> o arquivo usa ponto e vírgula
            # usecols=range(10) -> o arquivo traz colunas vazias no final; lemos só as 10 primeiras
            return pd.read_csv(caminho, sep=";", usecols=range(10))
    raise FileNotFoundError("Base não encontrada. Coloque o arquivo na pasta 'data/'.")


# ===========================================================================
# SPRINT 2 - FUNÇÕES DE LIMPEZA (texto, inteiros, decimais) E DATAS
# ===========================================================================
def limpar_texto(serie):
    """Padroniza texto: tira espaços sobrando, deixa maiúsculo e remove espaços duplicados (regex)."""
    serie = serie.astype(str).str.strip().str.upper()
    return serie.str.replace(r"\s+", " ", regex=True)


def limpar_inteiro(serie):
    """Mantém só dígitos (regex) e converte para inteiro. Valores inválidos viram nulo (<NA>)."""
    apenas_digitos = serie.astype(str).str.replace(r"[^\d]", "", regex=True)
    return pd.to_numeric(apenas_digitos, errors="coerce").astype("Int64")


def limpar_decimal(serie):
    """Converte '12,50' ou 'R$ 12,50' para 12.5. (Esta base não tem colunas decimais;
    a função fica pronta para bases com preço, por exemplo.)"""
    texto = serie.astype(str).str.replace(r"[^\d,.]", "", regex=True)
    texto = texto.str.replace(",", ".", regex=False)
    return pd.to_numeric(texto, errors="coerce")


def converter_data(texto):
    """Converte um texto 'dd/mm/aaaa' em data usando o módulo datetime.
    Se a data for inválida, devolve None (nulo) em vez de quebrar o programa."""
    try:
        return datetime.strptime(texto, FORMATO_DATA)
    except (ValueError, TypeError):
        return None


def converter_coluna_data(serie):
    """Aplica converter_data só nas datas ÚNICAS (são poucas) e depois mapeia para a coluna toda.
    É muito mais rápido do que converter linha por linha."""
    datas_unicas = serie.unique()
    tabela_de_para = {texto: converter_data(texto) for texto in datas_unicas}
    return pd.to_datetime(serie.map(tabela_de_para))


# ===========================================================================
# PROGRAMA PRINCIPAL
# ===========================================================================
def main():
    relatorio = {}  # guarda os "contadores" que vamos mostrar no fim

    # ------------------------------- SPRINT 1 -------------------------------
    titulo("SPRINT 1 - IMPORTAÇÃO E VISÃO GERAL")
    df = carregar_base()
    relatorio["registros lidos"] = len(df)

    print(f"\nNúmero de registros: {df.shape[0]}")
    print(f"Número de colunas:   {df.shape[1]}")
    print("\nColunas e tipos de dados:")
    print(df.dtypes)

    # Renomeamos as colunas para nomes mais claros (minúsculas e em português)
    df = df.rename(columns={
        "DATA": "data", "CO_ID": "id_compra", "CL_ID": "id_cliente",
        "CL_GENERO": "genero", "CL_EC": "estado_civil", "CL_FHL": "num_filhos",
        "CL_SEG": "segmento", "PR_ID": "id_produto", "PR_CAT": "categoria",
        "PR_NOME": "produto",
    })

    # --------------------- DIAGNÓSTICO (problemas na base) ------------------
    titulo("DIAGNÓSTICO - PROBLEMAS ENCONTRADOS")
    nulos = df.isnull().sum().sum()
    duplicatas = df.duplicated().sum()
    categorias_nd = (df["categoria"] == "#N/D").sum()
    datas_invalidas = converter_coluna_data(df["data"]).isnull().sum()

    print(f"1) Valores nulos (todas as colunas): {nulos}")
    print(f"2) Linhas duplicadas:                {duplicatas}")
    print(f"3) Categorias com '#N/D':            {categorias_nd}")
    print(f"4) Datas inválidas:                  {datas_invalidas}")

    # ------------------------------- SPRINT 2 -------------------------------
    titulo("SPRINT 2 - LIMPEZA DE TEXTO, INTEIROS E DATAS")
    # Texto
    for coluna in ["genero", "segmento", "categoria", "produto"]:
        df[coluna] = limpar_texto(df[coluna])
    # Inteiros
    for coluna in ["id_compra", "id_cliente", "estado_civil", "num_filhos", "id_produto"]:
        df[coluna] = limpar_inteiro(df[coluna])
    # Datas (módulo datetime) + colunas auxiliares de ano e mês
    df["data"] = converter_coluna_data(df["data"])
    df["ano"] = df["data"].dt.year
    df["mes"] = df["data"].dt.month
    print("Texto padronizado, inteiros convertidos e coluna 'data' em datetime.")
    print(df.dtypes)

    # Validação da regra do identificador de compra:
    # cada id_compra deve pertencer a UM cliente e a UMA data.
    por_compra = df.groupby("id_compra").agg(
        clientes=("id_cliente", "nunique"), datas=("data", "nunique")
    )
    compras_erradas = ((por_compra["clientes"] > 1) | (por_compra["datas"] > 1)).sum()
    relatorio["compras (id_compra) distintas"] = len(por_compra)
    relatorio["compras que violam a regra"] = compras_erradas
    print(f"\nRegra do id_compra: {compras_erradas} compras com mais de 1 cliente ou 1 data "
          f"(esperado: 0). Cada id_compra identifica uma compra única.")

    # ------------------------------- SPRINT 3 -------------------------------
    titulo("SPRINT 3 - NULOS E DUPLICATAS")

    # 3.1 Nulos: lógica if/else para categorias vazias
    # O '#N/D' (erro de planilha) é tratado como categoria vazia. Não apagamos essas linhas
    # porque são compras reais; só marcamos a categoria como "SEM CATEGORIA".
    def tratar_categoria(valor):
        if valor == "#N/D" or valor == "" or valor == "NAN":
            return CATEGORIA_VAZIA
        else:
            return valor

    df["categoria"] = df["categoria"].apply(tratar_categoria)
    df["produto"] = df["produto"].apply(lambda v: CATEGORIA_VAZIA if v in ("#N/D", "", "NAN") else v)
    preenchidas = (df["categoria"] == CATEGORIA_VAZIA).sum()
    relatorio["categorias preenchidas com 'SEM CATEGORIA'"] = preenchidas
    print(f"Categorias vazias preenchidas com '{CATEGORIA_VAZIA}': {preenchidas}")
    print("Dimensões físicas (peso, altura...): esta base não possui essas colunas, então não há o que tratar.")
    print(f"Nulos restantes: {df.isnull().sum().sum()}")

    # 3.2 Duplicatas: a base não tem coluna de quantidade. Uma linha repetida dentro da
    # mesma compra significa que o item foi comprado mais de uma vez. Então:
    #   - contamos quantas vezes cada linha se repete -> coluna 'quantidade'
    #   - eliminamos as linhas repetidas, mantendo só uma por item (sem perder informação)
    df["quantidade"] = df.groupby(list(df.columns)).transform("size")
    antes = len(df)
    df = df.drop_duplicates().reset_index(drop=True)
    relatorio["duplicatas removidas"] = antes - len(df)
    relatorio["registros após limpeza"] = len(df)
    print(f"Linhas duplicadas eliminadas: {antes - len(df)} (viraram a coluna 'quantidade')")
    print(f"Total de itens vendidos (soma de quantidade): {df['quantidade'].sum()}")

    # 3.3 Salva a base limpa
    df.to_csv(ARQUIVO_SAIDA, index=False, sep=";")
    print(f"Base limpa salva em: {ARQUIVO_SAIDA}")

    # ------------------------------- SPRINT 4 -------------------------------
    titulo("SPRINT 4 - ESTATÍSTICA DESCRITIVA: NÚMERO DE FILHOS")
    # Cada cliente aparece em várias linhas; para não contar o mesmo cliente várias vezes,
    # pegamos um registro por cliente.
    clientes = df.drop_duplicates(subset="id_cliente")
    filhos = clientes["num_filhos"].astype(int)

    print(f"Contagem (clientes): {filhos.count()}")
    print(f"Média:               {filhos.mean():.2f}")
    print(f"Mediana:             {filhos.median():.1f}")
    print(f"Desvio padrão:       {filhos.std():.2f}")
    print(f"Moda:                {filhos.mode()[0]}")
    print(f"Mínimo:              {filhos.min()}")
    print(f"Máximo:              {filhos.max()}")
    print(f"Quartil 1 (25%):     {filhos.quantile(0.25):.1f}")
    print(f"Quartil 2 (50%):     {filhos.quantile(0.50):.1f}")
    print(f"Quartil 3 (75%):     {filhos.quantile(0.75):.1f}")
    print("\nClientes por número de filhos:")
    print(filhos.value_counts().sort_index())

    # ------------------------------- SPRINT 5 -------------------------------
    titulo("SPRINT 5 - AGRUPAMENTOS")

    # Agrupamento 1: vendas e compras por gênero (groupby)
    por_genero = df.groupby("genero").agg(
        itens_vendidos=("quantidade", "sum"),
        compras=("id_compra", "nunique"),
        clientes=("id_cliente", "nunique"),
    )
    por_genero["itens_por_compra"] = (por_genero["itens_vendidos"] / por_genero["compras"]).round(1)
    print("\n1) Vendas por gênero:")
    print(por_genero)

    # Agrupamento 2: itens vendidos por categoria e segmento (pivot_table)
    por_categoria = df.pivot_table(
        index="categoria", columns="segmento", values="quantidade", aggfunc="sum"
    )
    por_categoria["TOTAL"] = por_categoria.sum(axis=1)
    por_categoria = por_categoria.sort_values("TOTAL", ascending=False)
    print("\n2) Itens vendidos por categoria x segmento:")
    print(por_categoria)

    # Agrupamento 3: itens vendidos por ano (groupby)
    por_ano = df.groupby("ano")["quantidade"].sum()
    print("\n3) Itens vendidos por ano (2022 vai só até 08/12):")
    print(por_ano)

    # Agrupamento 4: quem mais compra (top 5 clientes)
    top_clientes = (df.groupby("id_cliente")
                      .agg(itens=("quantidade", "sum"), compras=("id_compra", "nunique"))
                      .sort_values("itens", ascending=False).head(5))
    print("\n4) Top 5 clientes por itens comprados:")
    print(top_clientes)

    # Top 5 produtos
    top_produtos = df.groupby("produto")["quantidade"].sum().sort_values(ascending=False).head(5)
    print("\n5) Top 5 produtos mais vendidos:")
    print(top_produtos)

    # ------------------------- RELATÓRIO FINAL (contadores) -----------------
    titulo("RELATÓRIO FINAL - CONTADORES")
    relatorio["clientes distintos"] = df["id_cliente"].nunique()
    relatorio["produtos distintos (id_produto)"] = df["id_produto"].nunique()
    relatorio["período"] = f"{df['data'].min().date()} a {df['data'].max().date()}"
    for nome, valor in relatorio.items():
        print(f"- {nome}: {valor}")


# Só executa o programa se este arquivo for rodado diretamente (boa prática)
if __name__ == "__main__":
    main()
