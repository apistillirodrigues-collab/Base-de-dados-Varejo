# Mini-Projeto: Análise Exploratória da Base Varejo

Mini-Projeto Avaliativo do Módulo 1 do curso *Análise de Dados com Python*.
Aluno: *Adriano Pistilli Rodrigues*| Turma: *Analise_de_Dados*

## Objetivo
Fazer uma Análise Exploratória de Dados (AED) da base de compras de um varejo: conhecer os dados,
identificar problemas de qualidade, limpar a base, calcular estatísticas e responder perguntas simples de negócio.

## Estrutura do repositório
| Arquivo | Descrição |
|---|---|
| `miniprojeto_varejo.py` | Script principal, comentado e dividido em Sprints |
| `data/Base_Varejo_csv.zip` | Base original (Kaggle: namespaiva/base-varejo) |
| `df_limpo.csv` | Base após a limpeza (gerada pelo script) |
| `relatorio_execucao.txt` | Saída do script no terminal (relatório final) |
| `README_Adriano Pistilli_Analise_de_Dados_T1.md` | Instruções de execução |

## Como executar
Veja o arquivo `README_Adriano Pistilli_Analise_de_Dados_T1.md`. Resumo: `python miniprojeto_varejo.py`.
Requisitos: Python 3.9+ e `pandas`.

## O que o script faz
1. **Sprint 1:** leia a base com `pd.read_csv()` e mostre registros, colunas e tipos.
2. **Sprint 2:** funções de limpeza de texto, inteiros e decimais (com expressões regulares) e conversão de datas com o módulo `datetime`. Também valida a regra do `id_compra`.
3. **Sprint 3:** trate categorias vazias (`#N/D` → `SEM CATEGORIA`, com if/else) e elimine duplicatas.
4. **Sprint 4:** estatísticas do número de filhos dos clientes.
5. **Sprint 5:** agrupamentos (`groupby` e `pivot_table`) e relatório final com contadores.

## Decisões de limpeza
- **Nulos:** a base não tem células vazias, mas 3.650 linhas (produto 107) trazem `#N/D` em nome e categoria. Como são compras reais e o produto não tem como ser recuperado, **mantive as linhas** e marquei a categoria como `SEM CATEGORIA`. Apagá-las reduziria o total de vendas sem motivo.
- **Duplicatas:** 96.553 linhas eram idênticas. A base não tem coluna de quantidade, então assumi que uma linha repetida na mesma compra é o mesmo item comprado mais de uma vez. Eliminei as repetições e guardei a contagem na coluna `quantidade`, sem perder informação (a soma continua 830.000 itens). Essa é uma suposição: se as repetições fossem erro de digitação, bastaria usar só `drop_duplicates()` sem a coluna `quantidade`.
- **Tipos:** `data` virou `datetime`; ids, estado civil e número de filhos viraram inteiros.
- **Dimensões físicas:** a base não possui essas colunas, portanto não há o que tratar.
- **Regra do identificador de compra:** `id_compra` identifica uma compra única: nenhuma compra tem mais de um cliente ou mais de uma data (18.471 compras validadas).
- Interpretei `CL_FHL` como **número de filhos** e `CL_EC` como estado civil, com base nos valores (0 a 4 e 1 a 5). Isso deve ser confirmado no dicionário de dados da base.

## Principais insights
1. **Alimentos dominam as vendas:** 434.767 dos 830.000 itens (cerca de 52%), seguidos por Higiene (19%) e Limpeza (18%).
2. **Vendas crescendo ao longo do tempo:** 199.036 itens em 2019, 218.367 em 2020 e 245.259 em 2021. O ano de 2022 (167.338) está incompleto, pois os dados terminam em 08/12/2022, então não deve ser comparado diretamente.
3. **Gênero:** mulheres compram mais itens (432.576 contra 397.424) e fazem mais compras (9.615 contra 8.856), mas a média de itens por compra é praticamente a mesma (45,0 e 44,9). A diferença vem de haver mais clientes mulheres (519 contra 481), não de compras maiores.
4. **Segmentos diferem no volume, não no perfil:** o segmento B concentra cerca de 64% dos itens, o C 28% e o A 8%. Em todos eles, Alimentos representa cerca de 52% das compras.
5. **Número de filhos:** dos 1.000 clientes, 527 não têm filhos. Média 1,14, mediana 0, moda 0, desvio padrão 1,41, mínimo 0, máximo 4, quartis 0 / 0 / 2.
6. **Problemas remanescentes:** não há colunas de preço nem de quantidade (só dá para analisar volume, não faturamento); 3.650 itens seguem sem categoria; produtos com o mesmo nome aparecem com mais de um `id_produto` (ex.: PRESUNTO COZIDO tem 4 ids), o que pode distorcer rankings; e o significado de `CL_EC` e `CL_FHL` precisa ser confirmado.

## Reflexão teórica: ETL e qualidade de dados
**ETL** significa Extract, Transform, Load (extrair, transformar e carregar). Neste projeto, a *extração* foi a leitura do CSV com `pd.read_csv()`; a *transformação* foi a limpeza (padronizar textos, converter tipos e datas, tratar `#N/D` e duplicatas); e a *carga* foi salvar o `df_limpo.csv` pronto para análises ou dashboards.

A **qualidade dos dados** importa porque qualquer análise herda os erros da base. Se eu somasse as vendas sem notar as duplicatas, ou comparasse 2022 com os outros anos sem notar que ele está incompleto, chegaria a conclusões erradas com aparência de confiáveis. Neste trabalho verifiquei quatro dimensões: *completude* (nulos e `#N/D`), *validade* (datas e tipos corretos), *unicidade* (duplicatas) e *consistência* (cada `id_compra` pertence a um só cliente e a uma só data). Documentar cada decisão de limpeza também é parte da qualidade: outra pessoa precisa conseguir entender e reproduzir o que foi feito.
