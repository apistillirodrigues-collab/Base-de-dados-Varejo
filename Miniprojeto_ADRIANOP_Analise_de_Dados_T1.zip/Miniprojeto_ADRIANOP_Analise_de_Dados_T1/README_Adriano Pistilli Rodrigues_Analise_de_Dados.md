# Instruções de execução - Miniprojeto_NomeAluno_Analise_de_Dados_T1

## Opção 1: VsCode (ou terminal)
1. Instale o Python 3.9 ou superior e o pandas: `pip install pandas`
2. Baixe/clone este repositório e abra a pasta no VsCode.
3. Mantenha a base em `data/Base_Varejo_csv.zip` (já incluída).
4. No terminal, dentro da pasta, rode: `python miniprojeto_varejo.py`
5. O relatório aparece no terminal e o arquivo `df_limpo.csv` é gerado na mesma pasta.

## Opção 2: Google Colab
1. Acesse https://colab.research.google.com e crie um notebook novo.
2. Envie `miniprojeto_varejo.py` e `Base_Varejo_csv.zip` pelo painel de arquivos (ícone de pasta).
3. Em uma célula, rode: `!python miniprojeto_varejo.py`

## Resultado esperado
Relatório com: registros, colunas e tipos; problemas encontrados; limpeza; estatísticas do número de filhos; agrupamentos; e contadores finais. Um exemplo da saída está em `relatorio_execucao.txt`.
